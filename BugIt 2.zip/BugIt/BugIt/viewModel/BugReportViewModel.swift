//
//  BugReportViewModel.swift
//  BugIt
//
//  Created by Komal Bohra on 05/02/24.
//

import Foundation
import SwiftUI
import UIKit
import CoreGraphics
import GoogleAPIClientForREST
import GTMSessionFetcher
import GoogleSignIn
import Firebase
import FirebaseStorage
class BugReportViewModel: ObservableObject {
    @Published var showActionSheet = false
    @Published var screenshot: UIImage?
    @Published var descriptionText: String = ""
    @Published var imgUrl: String = ""
    @State private var showingImagePicker = false
    private let scopes = [kGTLRAuthScopeSheetsSpreadsheets, kGTLRAuthScopeSheetsSpreadsheetsReadonly]
    private let service = GTLRSheetsService()
    
    func handleOption1() {
        print("Option 1 selected")
        // Add any logic you want to execute when Option 1 is selected
    }

    func handleOption2() {
        showingImagePicker = true
    }
    func captureScreenshot() {
        let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene
        if let window = windowScene?.windows.first(where: { $0.isKeyWindow }) {
            self.screenshot = captureScreenshot(of: window)
        }
    }
    
    func submitBugReport(){
        //check the login
        signIn()
    }
    func captureScreenshot(of view: UIView) -> UIImage? {
        let renderer = UIGraphicsImageRenderer(size: view.bounds.size)
        let image = renderer.image { ctx in
            view.drawHierarchy(in: view.bounds, afterScreenUpdates: true)
        }
        return image
    }
    func signIn(){
        guard let presentingViewController = (UIApplication.shared.connectedScenes.first as? UIWindowScene)?.windows.first?.rootViewController else {return}

        guard let clientID = FirebaseApp.app()?.options.clientID else { return }
                
        let config = GIDConfiguration(clientID: clientID)

        GIDSignIn.sharedInstance.configuration = config
        
        GIDSignIn.sharedInstance.signIn(withPresenting: presentingViewController, hint: "Login",  additionalScopes: scopes)
      { signResult, error in
                    
            if let error = error {
                print(error)
               return
            }
                    
             guard let user = signResult?.user,
                   let idToken = user.idToken else { return }
             
             let accessToken = user.accessToken
                    
             let credential = GoogleAuthProvider.credential(withIDToken: idToken.tokenString, accessToken: accessToken.tokenString)

            // Use the credential to authenticate with Firebase
            self.uploadImage()
        }

    }
    func appendRow(spreadsheetId: String, range: String, values: [[Any]]) {
        let sheetsService = GTLRSheetsService()
        //sheetsService.authorizer = GIDSignIn.sharedInstance.currentUser?.authentication.fetcherAuthorizer()

        sheetsService.authorizer = GIDSignIn.sharedInstance.currentUser?.fetcherAuthorizer
        //sheetsService.authorizer = GIDSignIn.sharedInstance.currentUser?.authentication.fetcherAuthorizer()

        let valueRange = GTLRSheets_ValueRange()
        valueRange.values = values

        let query = GTLRSheetsQuery_SpreadsheetsValuesAppend.query(withObject: valueRange, spreadsheetId: spreadsheetId, range: range)
        query.valueInputOption = "USER_ENTERED"

        sheetsService.executeQuery(query) { (ticket, result, error) in
            if let error = error {
                print("Error appending row: \(error.localizedDescription)")
            } else {
                print("Row appended.")
                // Reset after submission for demonstration purposes
                self.screenshot = nil
                self.descriptionText = ""
            }
        }
    }
    func updateSheets() {
        let range = "BugIt" // Sheet titled , range A3 to C3
        let updateValues = [[descriptionText, imgUrl]]
        let valueRange = GTLRSheets_ValueRange() // GTLRSheets_ValueRange holds the updated values and other params
        valueRange.majorDimension = "ROWS" // Indicates horizontal row insert
        valueRange.range = range
        valueRange.values = updateValues
        let query = GTLRSheetsQuery_SpreadsheetsValuesAppend.query(withObject: valueRange, spreadsheetId: "1How8XzfaJmbonR0RrhwTbjUhqPsQ364m2qCX97Wzrt4", range: range) // Use an append query to append at the first blank row
        query.valueInputOption = "USER_ENTERED"
        
        let sheetsService = GTLRSheetsService()
        //sheetsService.authorizer = GIDSignIn.sharedInstance.currentUser?.authentication.fetcherAuthorizer()

        sheetsService.authorizer = GIDSignIn.sharedInstance.currentUser?.fetcherAuthorizer
        sheetsService.executeQuery(query) { ticket, object, error in
            print("object")
            if let error = error {
                print("Error appending row: \(error.localizedDescription)")
            } else {
                print("Row appended.")
            }
        } // `GTLRServiceCompletionHandler` closure containing the service ticket, `GTLRSheets_AppendValuesResponse`, and any error
    }
    func uploadImage(){
        guard let imageData = screenshot?.jpegData(compressionQuality: 0.8) else { return }
               let storage = Storage.storage()
               let storageRef = storage.reference()
               let imagesRef = storageRef.child("images/\(UUID().uuidString).jpg")

               imagesRef.putData(imageData, metadata: nil) { (metadata, error) in
                   guard metadata != nil else {
                       print(error?.localizedDescription ?? "Unknown error")
                       return
                   }
                   imagesRef.downloadURL { (url, error) in
                       guard let downloadURL = url else {
                           print(error?.localizedDescription ?? "Unknown error")
                           return
                       }
                       self.imgUrl =  "\(downloadURL)"
                       print("Download URL: \(downloadURL)")
                       self.updateSheets()
                   }
               }
           }
    
}

