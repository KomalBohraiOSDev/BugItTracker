//
//  BugItApp.swift
//  BugIt
//
//  Created by Komal Bohra on 06/02/24.
//

import SwiftUI

@main
struct BugItApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
