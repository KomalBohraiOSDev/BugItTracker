//
//  ContentView.swift
//  BugIt
//
//  Created by Komal Bohra on 05/02/24.
//

import SwiftUI
import GoogleSignIn

struct ContentView: View {
    
    var body: some View {
        BugReportView()
    }
}

struct ContentView_Previews: PreviewProvider {
    
    static var previews: some View {
        ContentView()
            
    }
}
