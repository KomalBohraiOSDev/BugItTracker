//
//  BugReportView.swift
//  BugIt
//
//  Created by Komal Bohra on 05/02/24.
//
//bugit-626@bugit-413312.iam.gserviceaccount.com
//711626571409-ra0e0e8qsa31on8bm28l92v7ggp816bq.apps.googleusercontent.com
import Foundation
import UIKit
import SwiftUI
struct BugReportView: View {
    @StateObject private var viewModel = BugReportViewModel()
    var body: some View {
        VStack {
            if let screenshot = viewModel.screenshot {
                Image(uiImage: screenshot)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .border(Color.black, width: 1)
            } else {
                Text("No image selected")
                    .frame(height: 200)
                    .border(Color.gray, width: 1)
            }
            
            TextField("Describe the issue", text: $viewModel.descriptionText)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button("Add Image") {
                viewModel.showActionSheet = true
            }
            .actionSheet(isPresented: $viewModel.showActionSheet) {
                       // Configure the action sheet
                       ActionSheet(
                           title: Text("Add Image"),
                           message: Text("Please select an option"),
                           buttons: [
                               .default(Text("Camera"), action: viewModel.handleOption1),
                               .default(Text("Photos"), action: viewModel.handleOption2),
                               .default(Text("ScreenShot"), action: viewModel.captureScreenshot),
                               .cancel()
                           ]
                       )
                   }
            .padding()
            
            Button("Submit Bug Report") {
                viewModel.submitBugReport()
            }
            .disabled(viewModel.screenshot == nil || viewModel.descriptionText.isEmpty)
            .padding()
        }
        .padding()
    }
}
